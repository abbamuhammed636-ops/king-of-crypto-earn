const express = require("express");
const path = require("path");
const crypto = require("crypto");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("data.sqlite");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  referral_code TEXT NOT NULL UNIQUE,
  balance INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}
function makeReferralCode() {
  return crypto.randomBytes(5).toString("hex").toUpperCase();
}

app.post("/api/register", (req, res) => {
  const { name, phone, email, password } = req.body || {};
  if (!name || !phone || !email || !password || password.length < 6)
    return res.status(400).json({ error: "Fill all fields; password must be 6+ characters." });

  try {
    let code = makeReferralCode();
    while (db.prepare("SELECT 1 FROM users WHERE referral_code=?").get(code)) code = makeReferralCode();

    const result = db.prepare(`
      INSERT INTO users (name, phone, email, password_hash, referral_code)
      VALUES (?, ?, ?, ?, ?)
    `).run(name.trim(), phone.trim(), email.trim().toLowerCase(), hashPassword(password), code);

    res.json({ id: result.lastInsertRowid, name, email, referral_code: code, balance: 0 });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Email already registered." });
    res.status(500).json({ error: "Registration failed." });
  }
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email=?").get((email || "").trim().toLowerCase());
  if (!user || user.password_hash !== hashPassword(password || ""))
    return res.status(401).json({ error: "Invalid email or password." });

  res.json({
    id: user.id, name: user.name, email: user.email,
    phone: user.phone, referral_code: user.referral_code, balance: user.balance
  });
});

app.get("/api/dashboard/:id", (req, res) => {
  const user = db.prepare("SELECT id,name,email,phone,referral_code,balance,created_at FROM users WHERE id=?").get(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ ...user, sales: 0, referrals: 0, pending: 0 });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`King of Crypto Earn running on http://localhost:${PORT}`));
