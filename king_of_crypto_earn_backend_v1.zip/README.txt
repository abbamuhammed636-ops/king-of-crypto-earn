KING OF CRYPTO EARN — BACKEND V1

What is included:
- Node.js + Express backend
- SQLite database
- Real server-side registration
- Real server-side login validation
- Password hashing for this starter
- User records and unique referral codes
- Dashboard API
- Responsive register/login/dashboard UI

Run locally:
1. Install Node.js 20+.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run: npm install
5. Run: npm start
6. Open: http://localhost:3000

IMPORTANT PRODUCTION SECURITY:
This is a starter, not a production financial platform. Before accepting real money:
- Replace SHA-256 password hashing with Argon2id or bcrypt.
- Add secure sessions/JWT, rate limiting, CSRF protection and email/phone verification.
- Use HTTPS.
- Add server-side authorization for every user resource.
- Add a proper wallet ledger; never let users directly edit balances.
- Integrate a compliant Nigerian payment provider and bank-transfer workflow.
- Add KYC/AML and applicable Nigerian legal/compliance review.
- Add fraud detection, audit logs and admin controls.
- Never promise guaranteed returns or pay users merely for depositing money; earnings should be tied to genuine sales/clearly disclosed commissions.
